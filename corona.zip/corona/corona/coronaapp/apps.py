from django.apps import AppConfig


class CoronaappConfig(AppConfig):
    name = 'coronaapp'
